"""Resolución de rutas compartidas por aplicación y runtime efímero."""

from __future__ import annotations

import re
from pathlib import Path

_PATH_SEGMENT_PATTERN = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$')


def validate_path_segment(value: str, *, name: str) -> str:
    """Valida una identidad antes de utilizarla como segmento de ruta."""

    if not isinstance(value, str):
        raise TypeError(f'{name} must be a string')
    if not _PATH_SEGMENT_PATTERN.fullmatch(value):
        raise ValueError(
            f'{name} must contain only letters, numbers, dots, underscores, or hyphens'
        )
    return value


def resolve_application_root(volume_path: str | Path, *, application: str) -> Path:
    """Retorna la raíz funcional que contiene logs y datasets de una aplicación."""

    if not isinstance(volume_path, str | Path):
        raise TypeError('volume_path must be a string or Path')
    raw_volume_path = str(volume_path)
    if not raw_volume_path:
        raise ValueError('volume_path must not be empty')
    resolved_volume_path = Path(raw_volume_path)
    if not resolved_volume_path.is_absolute():
        raise ValueError('volume_path must be an absolute path')
    application_segment = validate_path_segment(application, name='application')
    return resolved_volume_path / application_segment


def resolve_runtime_root(volume_path: str | Path, *, application: str) -> Path:
    """Retorna la raíz oculta destinada a coordinación y estado temporal."""

    return resolve_application_root(volume_path, application=application) / '.runtime'
